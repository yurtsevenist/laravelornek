<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contact;
class ContactController extends Controller
{
        public function contactPost(Request $request)
        {
            // Eski input değerlerini session'a flash et
            $request->flash();

            // Validation kuralları ve Türkçe attribute isimleri
            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255',
                'message' => 'required|string|max:500',
                'phone' => ['nullable', 'regex:/^\+?[0-9\s\-\(\)]{10,20}$/'], // gevşetilmiş telefon kontrolü
            ], [], [
                'name' => 'Adınız Soyadınız',
                'email' => 'E-Posta Adresi',
                'message' => 'Mesajınız',
                'phone' => 'Telefon Numarası',
            ]);

            try {
                // Yeni Contact kaydı oluştur
                $mesaj = new Contact;
                $mesaj->name = $request->name;
                $mesaj->phone = $request->phone;
                $mesaj->email = $request->email;
                $mesaj->message = $request->message;
                $mesaj->save();

                // Başarılı mesajı session ile geri döndür
                return redirect()->back()->with('success', 'Mesajınız başarıyla gönderildi!');
            } catch (\Exception $e) {
                // Hata oluşursa session ile geri döndür ve hata mesajını göster
                return redirect()->back()->with('error', 'Mesaj gönderilirken bir hata oluştu! Lütfen tekrar deneyin.');
            }
        }

}
