<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


class AuthController extends Controller
{
    public function login()
    {
        return view('auth.login');
    }
    public function register()
    {
        return view('auth.register');
    }
    public function forget()
    {
        return view('auth.forget');
    }
public function loginPost(Request $request)
{
    // 1️⃣ Validasyon
    $request->validate([
        'email'    => 'required|email',
        'password' => 'required',
    ]);

    // 2️⃣ Giriş bilgileri
    $credentials = $request->only('email', 'password');

    // 3️⃣ Remember me (checkbox)
    $remember = $request->has('remember');

    // 4️⃣ Giriş denemesi
    if (Auth::attempt($credentials, $remember)) {
        $request->session()->regenerate();
        if(Auth::user()->who==0)
            {                
                return redirect()->intended('/')->with('success', 'Giriş başarılı');
            }
        else
            {
               return redirect()->intended('/dashboard')->with('success', 'Hoşgeldin '.Auth::user()->name);
            }        
    }

    // 5️⃣ Hatalı giriş
    return back()->withErrors([
        'email' => 'Email veya şifre hatalı',
    ])->withInput($request->only('email'));
}
public function logout(Request $request)
{
    Auth::logout();

    // Session güvenliği
    $request->session()->invalidate();
    $request->session()->regenerateToken();

    return redirect('/')->with("info","Oturum kapatıldı");
}
public function registerPost(Request $request)
{
    // 1️⃣ Validasyon
        $request->validate(
            [
                'name'     => 'required|string|max:255',
                'email'    => 'required|email|unique:users,email',
                'password' => 'required|min:6|confirmed',
                'accept'   => 'required|accepted',
            ],
            [
                'accept.accepted' => 'Üyelik sözleşmesini kabul etmelisiniz.',
            ],
            [
                'name'     => 'Ad Soyad',
                'email'    => 'E-posta Adresi',
                'password' => 'Şifre',
                'accept'   => 'Üyelik Sözleşmesi',
            ]
        );


    // 2️⃣ Kullanıcı oluştur
    $user = User::create([
        'name'     => $request->name,
        'email'    => $request->email,
        'password' => Hash::make($request->password),
        'who'      => 0, // normal kullanıcı
    ]);

    // 3️⃣ Otomatik login
    Auth::login($user);

    // 4️⃣ Redirect + mesaj
    if(Auth::user()->who==0)
            {                
                return redirect()->intended('/')->with('success', 'Giriş başarılı');
            }
        else
            {
               return redirect()->intended('/dashboard')->with('success', 'Hoşgeldin '.Auth::user()->name);
            }       
}

}
