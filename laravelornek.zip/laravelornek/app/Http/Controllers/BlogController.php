<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blog;
use App\Models\Readcount;
use App\Models\Likecount;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
class BlogController extends Controller
{
    public function index()
    {
        $lastBlogs=Blog::orderBy('created_at','DESC')->take(10)->get();
        return view('main',compact('lastBlogs'));
    }
    public function blogDetay(Request $request,$id,$slug)
    {
        $blog=Blog::whereId($id)->first();
        $ip=$request->ip();
        $kayitara=Readcount::whereIp($ip)->whereBlog_id($blog->id)->first();
        if(!$kayitara)//eğer bu blog yazısı bu ip tarafından okunmamış ise
        {
            $blog->readCount+=1;
            $blog->save();
            $yenikayit=new Readcount;
            $yenikayit->ip=$ip;
            $yenikayit->blog_id=$blog->id;
            $yenikayit->save();
        }
        return view('postdetail',compact('blog'));
    }
    public function blogs()
    {
        $allBlogs=Blog::orderBy('readCount','DESC')->paginate(10);
        $blogcount=Blog::get()->count();
        $readcount=Blog::get()->sum('readCount');
        $likecount=Blog::get()->sum('likeCount');
        $yazar=null;
        $kategori=null;

        return view('blogs',compact('allBlogs','blogcount','yazar','readcount','likecount','kategori'));
    }
    public function like(Request $request, $id)
    {
        $blog = Blog::findOrFail($id);     
       
        // Beğeni kontrolü
         $ip=$request->ip();
        $liked=Likecount::whereIp($ip)->whereBlog_id($blog->id)->first();
        if($liked){
            // Beğeniyi geri al
            $liked->delete();
            $likedNow = false;
            $blog->likeCount-=1;
            $blog->save();
        } else {
            // Beğen
            $yenikayit=new Likecount;
            $yenikayit->ip=$ip;
            $yenikayit->blog_id=$blog->id;
            $yenikayit->save();
            $blog->likeCount+=1;
            $blog->save();
            $likedNow = true;
        }
        // Güncel like sayısı
        $likeCount = $blog->likeCount;
        return response()->json([
            'liked' => $likedNow,
            'likeCount' => $likeCount
        ]);
    }
    public function blogYazilari($tur,$slug)
    {
        if($tur=="yazar")
        {
            $blogs=Blog::get();
            $yazar=null;
            $kategori=null;
            //yazarı buluyoruz neden çünkü yazar ismi db de slug değil 
            foreach($blogs as $blog)
            {
                if($slug==Str::slug($blog->author))
                {
                    $yazar=$blog->author;
                    break;
                }
            }
            //yazarın yazılarını aldık
            $allBlogs=Blog::whereAuthor($yazar)->orderBy('readCount','DESC')->paginate(10);
            $blogcount=Blog::whereAuthor($yazar)->get()->count();
            $readcount=Blog::whereAuthor($yazar)->get()->sum('readCount');
            $likecount=Blog::whereAuthor($yazar)->get()->sum('likeCount');
        }
        else
        {
            $blogs=Blog::get();
            $kategori=null;
            $yazar=null;
            //yazarı buluyoruz neden çünkü yazar ismi db de slug değil 
            foreach($blogs as $blog)
            {
                if($slug==Str::slug($blog->category))
                {
                    $kategori=$blog->category;
                    break;
                }
            }
            //yazarın yazılarını aldık
            $allBlogs=Blog::whereCategory($kategori)->orderBy('readCount','DESC')->paginate(10);
            $blogcount=Blog::whereCategory($kategori)->get()->count();
            $readcount=Blog::whereCategory($kategori)->get()->sum('readCount');
            $likecount=Blog::whereCategory($kategori)->get()->sum('likeCount');
        }

        return view('blogs',compact('allBlogs','blogcount','yazar','readcount','likecount','kategori'));
    }

}
