<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class IsAdmin
{
    public function handle(Request $request, Closure $next)
    {
        // Giriş yapılmamışsa
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        // Admin değilse (who != 1)
        if (Auth::user()->who != 1) {
             return redirect()->intended('/')->with('success', 'Giriş başarılı');
        }

        return $next($request);
    }
}
