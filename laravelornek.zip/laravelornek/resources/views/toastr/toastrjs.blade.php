            <!-- jQuery -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

            <!-- Toastr JS -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

            <script>
            toastr.options = {
                closeButton: true,
                progressBar: true,
                positionClass: "toast-top-right",
                timeOut: 3000
            };

            @if(session('success'))
                toastr.success("{{ session('success') }}");
            @endif

            @if(session('info'))
                toastr.info("{{ session('info') }}");
            @endif

            @if(session('warning'))
                toastr.warning("{{ session('warning') }}");
            @endif

            @if(session('error'))
                toastr.error("{{ session('error') }}");
            @endif
            </script>

        <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const backToTop = document.getElementById('backToTop');

                    // Scroll olduğunda butonu göster/gizle
                    window.addEventListener('scroll', function() {
                        if (window.scrollY > 200) { // 200px aşağıya inince göster
                            backToTop.style.display = 'block';
                        } else {
                            backToTop.style.display = 'none';
                        }
                    });

                    // Butona tıklayınca sayfanın başına dön
                    backToTop.addEventListener('click', function() {
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    });
                });
    </script>
