<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Metenin Dünyası-@yield('title')</title>
        <link rel="icon" type="image/x-icon" href="{{asset('temafront')}}/assets/img/logo.png" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="{{asset('temafront')}}/css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        @yield('css')
    </head>
    <body>
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="{{route('/')}}">
                    <img src="{{asset('temafront')}}/assets/img/logo.png" width="30px" alt="" srcset=""> 
                    Metenin Dünyası
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menü
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4 @if(Request::segment(1)=='') text-warning @endif" href="{{route('/')}}">Anasayfa</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4 @if(Request::segment(1)=='hakkimda') text-warning @endif" href="{{route('hakkimda')}}">Hakkımda</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4 @if(Request::segment(1)=='blog-yazilarim' or Request::segment(1)=='blog-detay' or Request::segment(1)=='blog-yazilari') text-warning @endif" href="{{route('blog-yazilarim')}}">Blog Yazılarım</a></li>
                        <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4 @if(Request::segment(1)=='iletisim') text-warning @endif" href="{{route('iletisim')}}">İletişim</a></li>
                        @auth
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle px-lg-3 py-3 py-lg-4
        @if(Request::segment(1)=='hesap') text-warning @endif"
        href="#"
        role="button"
        data-bs-toggle="dropdown"
        aria-expanded="false">

        {{ Auth::user()->name }}
    </a>

    <ul class="dropdown-menu dropdown-menu-end">
        <li>
            <a class="dropdown-item" href="#">
                Hesap
            </a>
        </li>

        <li><hr class="dropdown-divider"></li>

        <li>
            <form method="POST" action="{{route('logout')}}">
                @csrf
                <button class="dropdown-item text-danger" type="submit">
                    Oturumu Kapat
                </button>
            </form>
        </li>
    </ul>
</li>

                        @else
                                                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4 @if(Request::segment(1)=='giris') text-warning @endif" href="{{route('giris')}}">Oturum Aç</a></li>
                        @endauth

                    </ul>
                </div>
            </div>
        </nav>