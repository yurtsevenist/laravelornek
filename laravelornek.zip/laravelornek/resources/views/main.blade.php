    @extends('layouts.master')
    @section('title','Anasayfa')
    @section('content')
        <!-- Page Header-->
        <header class="masthead" style="background-image: url('{{asset('temafront')}}/assets/img/home-bg.jpg')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="site-heading text-center">
                            <h1 class="display-4">@yield('title')</h1>                         
                        </div>
                    </div>
                </div>

            </div>
        </header>
        <!-- Main Content-->
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                        @foreach ($lastBlogs as $blog )
                                <!-- Post preview-->
                                <div class="post-preview">
                                    <a href="{{route('blog-detay',[$blog->id,Str::slug($blog->header)])}}">
                                        <img src="{{$blog->image}}" class="img-fluid" alt="...">
                                        <h2 class="post-title">{{$blog->header}}</h2>
                                        <h3 class="post-subtitle">{{$blog->summary}}</h3>
                                    </a>
                                    <p class="post-meta d-flex flex-wrap align-items-center gap-3 text-muted small">

                                        <span>
                                            <i class="fas fa-user text-secondary me-1"></i>
                                            <a href="{{route('blog-yazilari',['yazar',Str::slug($blog->author)])}}" class="text-decoration-none fw-semibold text-dark">
                                                {{$blog->author}}
                                            </a>
                                        </span>

                                        <span>
                                            <i class="fas fa-folder-open text-secondary me-1"></i>
                                            <a href="{{route('blog-yazilari',['kategori',Str::slug($blog->category)])}}" class="badge bg-light text-dark text-decoration-none border">
                                                {{$blog->category}}
                                            </a>
                                        </span>

                                        <span>
                                            <i class="far fa-clock text-secondary me-1"></i>
                                            {{$blog->created_at->diffForHumans()}}
                                        </span>

                                        <span title="Okunma Sayısı: {{$blog->readCount}}">
                                            <i class="fas fa-eye text-primary me-1"></i>
                                            {{$blog->readCount}}
                                        </span>

                                        <span title="Beğeni Sayısı: {{$blog->likeCount}}">
                                            <i class="fas fa-thumbs-up text-danger me-1"></i>
                                            {{$blog->likeCount}}
                                        </span>

                                    </p>

                                </div>
                                <!-- Divider-->
                                <hr class="my-4" />
                        @endforeach
               
                   
                    <div class="d-flex justify-content-end mb-4"><a class="btn btn-primary text-uppercase" href="{{route('blog-yazilarim')}}">Daha Fazla →</a></div>
                </div>
            </div>
        </div>
    @endsection
    @section('js')
        <script>
function updateTime() {
    const now = new Date();

    const day = String(now.getDate()).padStart(2,'0');
    const month = String(now.getMonth()+1).padStart(2,'0'); 
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2,'0');
    const minutes = String(now.getMinutes()).padStart(2,'0');
    const seconds = String(now.getSeconds()).padStart(2,'0');

    document.getElementById('live-time').textContent = `${day}.${month}.${year} ${hours}:${minutes}:${seconds}`;
}

function updateCountdown() {
    const now = new Date();
    const target = new Date('2026-06-26T00:00:00'); 

    let diff = target - now; 

    if(diff <= 0){
        document.getElementById('countdown').textContent = "Süre doldu!";
        return;
    }

    const weeks = Math.floor(diff / (1000*60*60*24*7));
    const days = Math.floor((diff / (1000*60*60*24)) % 7);
    const hours = Math.floor((diff / (1000*60*60)) % 24);
    const minutes = Math.floor((diff / (1000*60)) % 60);
    const seconds = Math.floor((diff / 1000) % 60);

    document.getElementById('countdown').textContent = 
        `${weeks} hafta ${days} gün ${hours} saat ${minutes} dakika ${seconds} saniye kaldı`;
}

// Başlangıçta çalıştır
updateTime();
updateCountdown();

// Her saniye güncelle
setInterval(() => {
    updateTime();
    updateCountdown();
}, 1000);



        </script>
    @endsection
