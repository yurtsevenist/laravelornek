    @extends('layouts.master')
    @section('title','Blog Yazılarım')
    @section('content')
        <!-- Page Header-->
<header class="masthead" style="background-image: url('{{asset('temafront')}}/assets/img/post-bg.jpg')">
    <div class="container position-relative px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7 text-center">
                
                <div class="post-heading">

                    <h1 class="mb-3">
                        @if($yazar == null && $kategori==null)
                            Tüm Blog Yazıları
                        @else
                            @if($yazar!=null)
                            <i class="fas fa-user-edit me-2"></i> {{$yazar}}
                            @else
                             <i class="fas fa-tags me-2"></i> {{$kategori}}
                            @endif
                        @endif
                    </h1>

                    <div class="d-flex flex-wrap justify-content-center gap-3 mt-4">

                        <div class="stat-box">
                            <i class="fas fa-file-alt"></i>
                            <span>{{$blogcount}}</span>
                            <small>Toplam Yazı</small>
                        </div>

                        <div class="stat-box">
                            <i class="fas fa-eye"></i>
                            <span>{{$readcount}}</span>
                            <small>Görüntülenme</small>
                        </div>

                        <div class="stat-box">
                            <i class="fas fa-thumbs-up"></i>
                            <span>{{$likecount}}</span>
                            <small>Beğeni</small>
                        </div>

                    </div>

                </div>

            </div>
        </div>
    </div>
</header>

    <!-- Main Content-->
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                        @foreach ($allBlogs as $blog )
                                <!-- Post preview-->
                                <div class="post-preview">
                                    <a href="{{route('blog-detay',[$blog->id,Str::slug($blog->header)])}}">
                                        <img src="{{$blog->image}}" class="img-fluid" alt="...">
                                        <h2 class="post-title">{{$blog->header}}</h2>
                                        <h3 class="post-subtitle">{{$blog->summary}}</h3>
                                    </a>
                                    <p class="post-meta d-flex flex-wrap align-items-center gap-3 text-muted small">

                                        <span>
                                            <i class="fas fa-user text-secondary me-1"></i>
                                            <a href="{{route('blog-yazilari',['yazar',Str::slug($blog->author)])}}" class="text-decoration-none fw-semibold text-dark">
                                                {{$blog->author}}
                                            </a>
                                        </span>

                                        <span>
                                            <i class="fas fa-folder-open text-secondary me-1"></i>
                                            <a href="{{route('blog-yazilari',['kategori',Str::slug($blog->category)])}}" class="badge bg-light text-dark text-decoration-none border">
                                                {{$blog->category}}
                                            </a>
                                        </span>

                                        <span>
                                            <i class="far fa-clock text-secondary me-1"></i>
                                            {{$blog->created_at->diffForHumans()}}
                                        </span>

                                        <span title="Okunma Sayısı: {{$blog->readCount}}">
                                            <i class="fas fa-eye text-primary me-1"></i>
                                            {{$blog->readCount}}
                                        </span>

                                        <span title="Beğeni Sayısı: {{$blog->likeCount}}">
                                            <i class="fas fa-thumbs-up text-danger me-1"></i>
                                            {{$blog->likeCount}}
                                        </span>

                                    </p>
                                </div>
                                <!-- Divider-->
                                <hr class="my-4" />
                        @endforeach
               
                   
                    <div class="d-flex justify-content-center mb-4">{{ $allBlogs->links('pagination::bootstrap-4') }}</div>
                </div>
            </div>
        </div>
        <!-- Footer-->
    @endsection
    @section('css')
        <style>
            .stat-box {
                background: rgba(236, 244, 8, 0.9);
                padding: 15px 20px;
                border-radius: 12px;
                min-width: 140px;
                text-align: center;
                box-shadow: 0 5px 15px rgba(0,0,0,0.15);
            }

            .stat-box i {
                font-size: 1.4rem;
                color: #0d6efd;
                margin-bottom: 5px;
            }

            .stat-box span {
                display: block;
                font-size: 1.4rem;
                font-weight: 700;
                color: #212529;
            }

            .stat-box small {
                color: #6c757d;
            }
            </style>

    @endsection