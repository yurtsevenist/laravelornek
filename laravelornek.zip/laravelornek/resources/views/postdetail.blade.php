    @extends('layouts.master')
    @section('title','Blog Detay')
    @section('content')
        <!-- Page Header-->
        <header class="masthead" style="background-image: url('{{$blog->image}}')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">

                        <div class="post-heading text-center">

                            <h1 class="mb-3">{{$blog->header}}</h1>

                            <h2 class="subheading text-muted mb-4">
                                {{$blog->summary}}
                            </h2>

                            <div class="post-meta d-flex flex-wrap justify-content-center align-items-center gap-3 small">

                                <!-- Yazar -->
                                <span>
                                    <i class="fas fa-user text-secondary me-1"></i>
                                    <a href="{{route('blog-yazilari',['yazar',Str::slug($blog->author)])}}"
                                    class="text-decoration-none fw-semibold text-dark">
                                        {{$blog->author}}
                                    </a>
                                </span>

                                <span class="text-muted">•</span>

                                <!-- Kategori -->
                                <span>
                                    <i class="fas fa-folder-open text-secondary me-1"></i>
                                    <a href="{{route('blog-yazilari',['kategori',Str::slug($blog->category)])}}"
                                    class="badge bg-light text-dark text-decoration-none border">
                                        {{$blog->category}}
                                    </a>
                                </span>

                                <span class="text-muted">•</span>

                                <!-- Tarih -->
                                <span class="text-muted">
                                    <i class="far fa-clock me-1"></i>
                                    {{$blog->created_at->diffForHumans()}}
                                </span>

                                <span class="text-muted">•</span>

                                <!-- Okunma -->
                                <span title="Okunma Sayısı: {{$blog->readCount}}">
                                    <i class="fas fa-eye text-primary me-1"></i>
                                    {{$blog->readCount}}
                                </span>

                                <span class="text-muted">•</span>

                                <!-- Beğeni -->
                                <span title="Beğeni Sayısı">
                                    <i class="fas fa-thumbs-up text-danger like-btn" id="like-btn"
                                    data-blog-id="{{$blog->id}}"
                                    style="cursor:pointer;"></i>
                                    <span class="like-count">{{$blog->likeCount}}</span>
                                </span>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </header>

        <!-- Post Content-->
        <article class="mb-4">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    {!!$blog->content!!}
                </div>
            </div>
        </article>
    @endsection
    @section('css')
        <!-- CSRF token meta -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <style>
            .post-meta {
                background: rgba(156, 207, 251, 0.85);
                padding: 10px 18px;
                border-radius: 30px;
                display: inline-flex;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            }

            .post-heading h1 {
                text-shadow: 0 3px 10px rgba(0,0,0,0.3);
            }

            .post-heading .subheading {
                text-shadow: 0 2px 8px rgba(0,0,0,0.25);
            }
            </style>

    @endsection
    @section('js')
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            $(document).ready(function(){
                // CSRF token tüm AJAX isteklerinde otomatik gönderilsin
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $('#like-btn').click(function(){
                    var btn = $(this);
                    var blogId = btn.data('blog-id');
                   
                    $.ajax({
                        url: '/blog/' + blogId + '/like',
                        type: 'POST',
                        success: function(response){
                           btn.siblings('.like-count').text(response.likeCount); // sayıyı güncelle
                        },
                        error: function(err){
                            console.log(err);
                            alert("Beğeni işlemi başarısız!");
                        }
                    });
                });

            });

        </script>

    @endsection