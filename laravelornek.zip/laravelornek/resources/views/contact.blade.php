    @extends('layouts.master')
    @section('title','İletişim')
    @section('content')
            <!-- Page Header-->
        <header class="masthead" style="background-image: url('{{asset('temafront')}}/assets/img/contact-bg.jpg')">
            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="page-heading">
                            <h1>@yield('title')</h1>
                            <span class="subheading">Bize her konuda ama her konuda yazabilirsiniz...</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <p>İletişime geçmek mi istiyorsunuz? Aşağıdaki formu doldurun, size en kısa sürede geri döneceğiz! * işaretli alanlar zorunludur.</p>
                        <div class="my-5">
                            <div class="container mb-4">
                                {{-- Başarı mesajı --}}
                                @if(session('success'))
                                    <div style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                                        {{ session('success') }}
                                    </div>
                                @endif

                                {{-- Bilgilendirme mesajı --}}
                                @if(session('info'))
                                    <div style="background-color: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                                        {{ session('info') }}
                                    </div>
                                @endif

                                {{-- Hata mesajı --}}
                                @if(session('error'))
                                    <div style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                                        {{ session('error') }}
                                    </div>
                                @endif

                                {{-- Validation hataları --}}
                                @if ($errors->any())
                                    <div style="background-color: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px;">
                                        <ul class="mb-0">
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif
                            </div>

                            <form method="POST" action="{{route("contactPost")}}" id="contactForm" data-sb-form-api-token="API_TOKEN">
                                @csrf
                                <div class="form-floating">
                                    <input class="form-control" id="name" name="name" value="{{old('name')}}" type="text" placeholder="Adınızı giriniz..."  required />
                                    <label for="name">*Adınız Soyadınız</label>
                                    <div class="invalid-feedback" data-sb-feedback="name:required">Ad gerekli.</div>
                                </div>

                                <div class="form-floating">
                                    <input class="form-control" id="email" name="email" value="{{old('email')}}" type="email" placeholder="E-posta adresinizi giriniz..." required />
                                    <label for="email">*E-Posta Adresi</label>
                                    <div class="invalid-feedback" data-sb-feedback="email:required">E-posta gerekli.</div>
                                    <div class="invalid-feedback" data-sb-feedback="email:email">Geçerli bir e-posta değil.</div>
                                </div>

                                <div class="form-floating">
                                    <input class="form-control" id="phone" name="phone" value="{{old('phone')}}" type="tel" placeholder="Telefon numaranızı giriniz..." />
                                    <label for="phone">Telefon Numarası</label>
                                    <div class="invalid-feedback" data-sb-feedback="phone:required">Telefon numarası geçersiz.</div>
                                </div>


                                <div class="form-floating">
                                    <textarea class="form-control" id="message" name="message" placeholder="Mesajınızı buraya yazın..." style="height: 12rem" required>{{old('message')}}</textarea>
                                    <label for="message">*Mesajınız</label>
                                    <div class="invalid-feedback" data-sb-feedback="message:required">Mesaj gerekli.</div>
                                    <!-- Karakter sayacı -->
                                    <small id="messageCounter" class="text-muted">500 karakter kaldı</small>
                                </div>

                                <br />

                                <div class="d-none" id="submitSuccessMessage">
                                    <div class="text-center mb-3">
                                        <div class="fw-bolder">Form başarıyla gönderildi!</div>
                                        Bu formu aktif hale getirmek için kayıt olun:
                                        <br />
                                        <a href="https://startbootstrap.com/solution/contact-forms">https://startbootstrap.com/solution/contact-forms</a>
                                    </div>
                                </div>

                                <div class="d-none" id="submitErrorMessage">
                                    <div class="text-center text-danger mb-3">Mesaj gönderilirken bir hata oluştu!</div>
                                </div>

                                <button class="btn btn-primary text-uppercase"  type="submit">
                                    Gönder
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </main>

    @endsection
    @section("js")
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const textarea = document.getElementById('message');
            const counter = document.getElementById('messageCounter');
            const maxChars = 500;

            textarea.addEventListener('input', function() {
                const remaining = maxChars - textarea.value.length;
                counter.textContent = remaining + ' karakter kaldı';

                // Maksimum sınır
                if(remaining < 0) {
                    textarea.value = textarea.value.substring(0, maxChars);
                    counter.textContent = '0 karakter kaldı';
                }
            });
        });
        </script>
                    <script>
            document.addEventListener('DOMContentLoaded', function() {
                const phoneInput = document.getElementById('phone');

                phoneInput.addEventListener('input', function(e) {
                    let x = phoneInput.value.replace(/\D/g, ''); // sadece rakamları al
                    if (x.length > 0) {
                        if(x[0] === '0') x = x.substring(1); // baştaki 0'ı kaldır
                        x = x.substring(0, 10); // maksimum 10 rakam
                        let formatted = '';
                        if(x.length > 0) formatted += '(' + x.substring(0,3) + ')';
                        if(x.length >= 4) formatted += ' ' + x.substring(3,6);
                        if(x.length >= 7) formatted += '-' + x.substring(6,10);
                        phoneInput.value = formatted;
                    }
                });
            });
            </script>


    @endsection
