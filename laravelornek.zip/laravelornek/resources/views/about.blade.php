    @extends('layouts.master')
    @section('title','Hakkımızda')
    @section('content')
        <!-- Page Header-->
     <header class="masthead"
        style="background-image: url('{{ $hakkimda?->image ?? asset('temafront/assets/img/post-bg.jpg') }}')">

            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="page-heading">
                            <h1>@yield('title')</h1>
                         <span class="subheading">
                        {!! $hakkimda?->header ?? '' !!}
                    </span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        {!! $hakkimda?->content ?? '' !!}
                </div>
            </div>
        </main>
    @endsection
