    
    <?php $__env->startSection('title','Blog Yazılarım'); ?>
    <?php $__env->startSection('content'); ?>
        <!-- Page Header-->
<header class="masthead" style="background-image: url('<?php echo e(asset('temafront')); ?>/assets/img/post-bg.jpg')">
    <div class="container position-relative px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7 text-center">
                
                <div class="post-heading">

                    <h1 class="mb-3">
                        <?php if($yazar == null && $kategori==null): ?>
                            Tüm Blog Yazıları
                        <?php else: ?>
                            <?php if($yazar!=null): ?>
                            <i class="fas fa-user-edit me-2"></i> <?php echo e($yazar); ?>

                            <?php else: ?>
                             <i class="fas fa-tags me-2"></i> <?php echo e($kategori); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </h1>

                    <div class="d-flex flex-wrap justify-content-center gap-3 mt-4">

                        <div class="stat-box">
                            <i class="fas fa-file-alt"></i>
                            <span><?php echo e($blogcount); ?></span>
                            <small>Toplam Yazı</small>
                        </div>

                        <div class="stat-box">
                            <i class="fas fa-eye"></i>
                            <span><?php echo e($readcount); ?></span>
                            <small>Görüntülenme</small>
                        </div>

                        <div class="stat-box">
                            <i class="fas fa-thumbs-up"></i>
                            <span><?php echo e($likecount); ?></span>
                            <small>Beğeni</small>
                        </div>

                    </div>

                </div>

            </div>
        </div>
    </div>
</header>

    <!-- Main Content-->
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                        <?php $__currentLoopData = $allBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Post preview-->
                                <div class="post-preview">
                                    <a href="<?php echo e(route('blog-detay',[$blog->id,Str::slug($blog->header)])); ?>">
                                        <img src="<?php echo e($blog->image); ?>" class="img-fluid" alt="...">
                                        <h2 class="post-title"><?php echo e($blog->header); ?></h2>
                                        <h3 class="post-subtitle"><?php echo e($blog->summary); ?></h3>
                                    </a>
                                    <p class="post-meta d-flex flex-wrap align-items-center gap-3 text-muted small">

                                        <span>
                                            <i class="fas fa-user text-secondary me-1"></i>
                                            <a href="<?php echo e(route('blog-yazilari',['yazar',Str::slug($blog->author)])); ?>" class="text-decoration-none fw-semibold text-dark">
                                                <?php echo e($blog->author); ?>

                                            </a>
                                        </span>

                                        <span>
                                            <i class="fas fa-folder-open text-secondary me-1"></i>
                                            <a href="<?php echo e(route('blog-yazilari',['kategori',Str::slug($blog->category)])); ?>" class="badge bg-light text-dark text-decoration-none border">
                                                <?php echo e($blog->category); ?>

                                            </a>
                                        </span>

                                        <span>
                                            <i class="far fa-clock text-secondary me-1"></i>
                                            <?php echo e($blog->created_at->diffForHumans()); ?>

                                        </span>

                                        <span title="Okunma Sayısı: <?php echo e($blog->readCount); ?>">
                                            <i class="fas fa-eye text-primary me-1"></i>
                                            <?php echo e($blog->readCount); ?>

                                        </span>

                                        <span title="Beğeni Sayısı: <?php echo e($blog->likeCount); ?>">
                                            <i class="fas fa-thumbs-up text-danger me-1"></i>
                                            <?php echo e($blog->likeCount); ?>

                                        </span>

                                    </p>
                                </div>
                                <!-- Divider-->
                                <hr class="my-4" />
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                   
                    <div class="d-flex justify-content-center mb-4"><?php echo e($allBlogs->links('pagination::bootstrap-4')); ?></div>
                </div>
            </div>
        </div>
        <!-- Footer-->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('css'); ?>
        <style>
            .stat-box {
                background: rgba(236, 244, 8, 0.9);
                padding: 15px 20px;
                border-radius: 12px;
                min-width: 140px;
                text-align: center;
                box-shadow: 0 5px 15px rgba(0,0,0,0.15);
            }

            .stat-box i {
                font-size: 1.4rem;
                color: #0d6efd;
                margin-bottom: 5px;
            }

            .stat-box span {
                display: block;
                font-size: 1.4rem;
                font-weight: 700;
                color: #212529;
            }

            .stat-box small {
                color: #6c757d;
            }
            </style>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\_Server_\Desktop\laravelprojelerim\laravelornek\resources\views/blogs.blade.php ENDPATH**/ ?>