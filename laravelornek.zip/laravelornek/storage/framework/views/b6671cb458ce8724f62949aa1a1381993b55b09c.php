    
    <?php $__env->startSection('title','Hakkımızda'); ?>
    <?php $__env->startSection('content'); ?>
        <!-- Page Header-->
     <header class="masthead"
        style="background-image: url('<?php echo e($hakkimda?->image ?? asset('temafront/assets/img/post-bg.jpg')); ?>')">

            <div class="container position-relative px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <div class="page-heading">
                            <h1><?php echo $__env->yieldContent('title'); ?></h1>
                         <span class="subheading">
                        <?php echo $hakkimda?->header ?? ''; ?>

                    </span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- Main Content-->
        <main class="mb-4">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-md-10 col-lg-8 col-xl-7">
                        <?php echo $hakkimda?->content ?? ''; ?>

                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\_Server_\Desktop\laravelprojelerim\laravelornek\resources\views/about.blade.php ENDPATH**/ ?>