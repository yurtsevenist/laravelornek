

<?php $__env->startSection('css'); ?>
<style>
.toggle-password {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
}
.toggle-password i {
    font-size: 1.1rem;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="register-box">
    <div class="card card-outline card-primary">
        <div class="card-header text-center">
            <a href="<?php echo e(url('/')); ?>" class="link-dark text-decoration-none">
                <h1 class="mb-0"><b>Admin</b>LTE</h1>
            </a>
        </div>

        <div class="card-body register-card-body">
            <p class="register-box-msg">Yeni bir üyelik oluştur</p>
             <?php echo $__env->make('toastr.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="<?php echo e(route('registerPost')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Ad Soyad -->
                <div class="input-group mb-2">
                    <div class="form-floating">
                        <input
                            type="text"
                            name="name"
                            value="<?php echo e(old('name')); ?>"
                            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="registerFullName"
                            placeholder="Ad Soyad"
                        >
                        <label for="registerFullName">Ad Soyad</label>
                    </div>
                    <div class="input-group-text">
                        <span class="bi bi-person"></span>
                    </div>
                </div>

                <!-- E-posta -->
                <div class="input-group mb-2">
                    <div class="form-floating">
                        <input
                            type="email"
                            name="email"
                            value="<?php echo e(old('email')); ?>"
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="registerEmail"
                            placeholder="E-posta"
                        >
                        <label for="registerEmail">E-posta</label>
                    </div>
                    <div class="input-group-text">
                        <span class="bi bi-envelope"></span>
                    </div>
                </div>

                <!-- Şifre -->
                <div class="input-group mb-2">
                    <div class="form-floating">
                        <input
                            type="password"
                            name="password"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            id="registerPassword"
                            placeholder="Şifre"
                        >
                        <label for="registerPassword">Şifre</label>
                    </div>
                    <button type="button"
                            class="btn btn-outline-secondary toggle-password"
                            data-target="registerPassword">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>

                <!-- Şifre Tekrar -->
                <div class="input-group mb-3">
                    <div class="form-floating">
                        <input
                            type="password"
                            name="password_confirmation"
                            class="form-control"
                            id="registerPasswordConfirm"
                            placeholder="Şifre Tekrar"
                        >
                        <label for="registerPasswordConfirm">Şifre Tekrar</label>
                    </div>
                    <button type="button"
                            class="btn btn-outline-secondary toggle-password"
                            data-target="registerPasswordConfirm">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>

                <!-- Kullanıcı Sözleşmesi -->
                <div class="row mb-3">
                    <div class="col-8 d-flex align-items-center">
                        <div class="form-check">
                            <input
                                class="form-check-input <?php $__errorArgs = ['accept'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                type="checkbox"
                                name="accept"
                                value="1"
                                id="acceptTerms"
                                <?php echo e(old('accept') ? 'checked' : ''); ?>

                            >
                            <label class="form-check-label" for="acceptTerms">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#termsModal">
                                    Kullanıcı sözleşmesini
                                </a> kabul ediyorum
                            </label>
                        </div>
                    </div>

                    <div class="col-4">
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">
                                Kayıt Ol
                            </button>
                        </div>
                    </div>
                </div>
            </form>

            <p class="mb-0 text-center">
                <a href="<?php echo e(route('giris')); ?>" class="link-primary">
                    Zaten üyeyim, giriş yap
                </a>
            </p>
        </div>
    </div>
</div>

<!-- Kullanıcı Sözleşmesi Modal -->
<div class="modal fade" id="termsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Kullanıcı Sözleşmesi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p><strong>1.</strong> Bu siteye kayıt olarak aşağıdaki şartları kabul etmiş sayılırsınız.</p>
                <p><strong>2.</strong> Kullanıcı bilgileri üçüncü kişilerle paylaşılmaz.</p>
                <p><strong>3.</strong> Site yönetimi gerekli gördüğü durumlarda üyeliği askıya alabilir.</p>
                <p><strong>4.</strong> Kullanıcı, sisteme yüklediği içeriklerden kendisi sorumludur.</p>
                <p><strong>5.</strong> Şartlar önceden haber verilmeksizin değiştirilebilir.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Kapat
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
document.querySelectorAll('.toggle-password').forEach(button => {
    button.addEventListener('click', function () {      
        const input = document.getElementById(this.dataset.target);
        const icon = this.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.replace('bi-eye', 'bi-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.replace('bi-eye-slash', 'bi-eye');
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\_Server_\Desktop\laravelprojelerim\laravelornek\resources\views/auth/register.blade.php ENDPATH**/ ?>