            <!-- jQuery -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

            <!-- Toastr JS -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

            <script>
            toastr.options = {
                closeButton: true,
                progressBar: true,
                positionClass: "toast-top-right",
                timeOut: 3000
            };

            <?php if(session('success')): ?>
                toastr.success("<?php echo e(session('success')); ?>");
            <?php endif; ?>

            <?php if(session('info')): ?>
                toastr.info("<?php echo e(session('info')); ?>");
            <?php endif; ?>

            <?php if(session('warning')): ?>
                toastr.warning("<?php echo e(session('warning')); ?>");
            <?php endif; ?>

            <?php if(session('error')): ?>
                toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>
            </script>

        <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const backToTop = document.getElementById('backToTop');

                    // Scroll olduğunda butonu göster/gizle
                    window.addEventListener('scroll', function() {
                        if (window.scrollY > 200) { // 200px aşağıya inince göster
                            backToTop.style.display = 'block';
                        } else {
                            backToTop.style.display = 'none';
                        }
                    });

                    // Butona tıklayınca sayfanın başına dön
                    backToTop.addEventListener('click', function() {
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    });
                });
    </script>
<?php /**PATH C:\Users\_Server_\Desktop\laravelprojelerim\laravelornek\resources\views/toastr/toastrjs.blade.php ENDPATH**/ ?>