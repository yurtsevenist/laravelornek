<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Blog>
 */
class BlogFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
     public function definition()
    {
        return [
            'header'     => $this->faker->sentence(6),
            'summary'    => $this->faker->paragraph(),
            'image'      => 'https://picsum.photos/id/' . $this->faker->numberBetween(1, 1000) . '/800/600',
            'content'    => $this->faker->paragraphs(6, true),
            'status'     => $this->faker->numberBetween(0, 2),
            'readCount'  => $this->faker->numberBetween(0, 5000),
            'likeCount'  => $this->faker->numberBetween(0, 500),

            // 👇 Sabit 10 yazardan rastgele
            'author'     => $this->faker->randomElement([
                'Ahmet Yılmaz',
                'Mehmet Kaya',
                'Ayşe Demir',
                'Fatma Çelik',
                'Ali Şahin',
                'Zeynep Arslan',
                'Mustafa Koç',
                'Elif Aydın',
                'Emre Yıldız',
                'Hatice Özkan',
            ]),

            'category'   => $this->faker->randomElement([
                'Eğitim',
                'Yazılım',
                'Teknoloji',
                'Bilişim',
                'Genel'
            ]),
        ];
    }


}
