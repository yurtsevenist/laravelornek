<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blogs', function (Blueprint $table) {
            $table->id();
            $table->string('header')->comment('blog yazısının başlığı');
            $table->text('summary')->nullable()->comment('blog özeti boş olabilir');
            $table->string('image')->comment('blog resmi');
            $table->mediumText('content')->comment('blog yazısı');
            $table->string('author')->default('Admin');
            $table->string('category')->default('Genel');
            $table->integer('status')->default(0)->comment('0 ise taslak 1 ise yayında 2 ise yayından kaldırılmış');
            $table->integer('readCount')->default(0)->comment('okunma sayısı');
            $table->integer('likeCount')->default(0)->comment('beğenme sayısı');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('blogs');
    }
};
