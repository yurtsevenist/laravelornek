<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Controller;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
//auth işlemleri
Route::get('giris',[AuthController::class,'login'])->name('giris');
Route::get('kayit',[AuthController::class,'register'])->name('kayit');
Route::get('sifremi-unuttum',[AuthController::class,'forget'])->name('sifremi-unuttum');
Route::post('loginPost',[AuthController::class,'loginPost'])->name('loginPost');
Route::post('registerPost',[AuthController::class,'registerPost'])->name('registerPost');
Route::post('forgetPost',[AuthController::class,'forgetPost'])->name('forgetPost');
Route::post('logout',[AuthController::class,'logout'])->name('logout');
//auth işlemleri sonu
Route::get('/',[BlogController::class,'index'])->name('/');
Route::get('iletisim',[Controller::class,'contact'])->name('iletisim');
Route::get('hakkimda',[Controller::class,'about'])->name('hakkimda');
Route::get('blog-yazilarim',[BlogController::class,'blogs'])->name('blog-yazilarim');
Route::get('blog-detay/{id}/{slug}',[BlogController::class,'blogDetay'])->name('blog-detay');
Route::post('/blog/{id}/like', [BlogController::class, 'like'])->name('blog.like');
Route::post('contactPost', [ContactController::class, 'contactPost'])->name('contactPost');
Route::get('blog-yazilari/{tur}/{slug}',[BlogController::class,'blogYazilari'])->name('blog-yazilari');

//admin rotaları
Route::middleware(['auth','isAdmin'])->group(function () {
  Route::get('dashboard',[DashboardController::class,'dashboard'])->name('dashboard');
});
//admin rotaları sonu

//kullanıcı rotaları
Route::middleware(['auth'])->group(function () {
  
});

//kullanıcı rotaları sonu